plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.localai.phone"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.localai.phone"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
    }

    // 매번 같은 서명으로 빌드해서, 새 APK 를 기존 앱 위에 그대로 설치(업데이트)할 수 있게 해요.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // 큰 파일(wasm 등)은 압축하지 않아야 앱이 빨리 열려요.
    androidResources {
        noCompress += listOf("wasm", "js", "html")
    }
}

// 외부 라이브러리 없이 안드로이드 기본 기능만 써요.
dependencies {
}
