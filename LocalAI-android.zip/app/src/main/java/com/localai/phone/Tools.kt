package com.localai.phone

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import org.json.JSONObject

object Tools {
    fun jok(vararg pairs: Pair<String, Any?>): String {
        val o = JSONObject()
        o.put("ok", true)
        for ((k, v) in pairs) o.put(k, v)
        return o.toString()
    }

    fun jerr(msg: String): String = JSONObject().put("ok", false).put("error", msg).toString()

    fun run(a: Activity, name: String, args: JSONObject): String {
        return when (name) {
            "open_app" -> openApp(a, args.optString("name"))
            "open_url" -> openUrl(a, args.optString("url"))
            "set_alarm" -> setAlarm(a, args.optString("time"), args.optString("label"))
            "add_note" -> addNote(a, args.optString("text"))
            "set_flashlight" -> flashlight(a, args.optBoolean("on", true))
            "set_volume" -> volume(a, args.optInt("level", 50))
            "read_screen" -> screen { it.readScreen() }
            "tap_text" -> screen { it.tapText(args.optString("text")) }
            "type_text" -> screen { it.typeText(args.optString("text")) }
            "press_key" -> screen { it.pressKey(args.optString("key")) }
            "scroll" -> screen { it.scroll(args.optString("direction", "down")) }
            else -> jerr("모르는 도구: $name")
        }
    }

    private fun screen(block: (PhoneService) -> String): String {
        val s = PhoneService.instance ?: return jerr("접근성 권한이 꺼져 있어요 (설정에서 켜기)")
        return block(s)
    }

    private fun openApp(a: Activity, wanted: String): String {
        val q = wanted.trim().lowercase()
        if (q.isEmpty()) return jerr("앱 이름이 비었어요")
        val pm = a.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(main, 0)
        var best: String? = null
        var bestLabel = ""
        for (ri in list) {
            val label = ri.loadLabel(pm).toString()
            val l = label.lowercase()
            if (l == q) { best = ri.activityInfo.packageName; bestLabel = label; break }
            if (best == null && (l.contains(q) || q.contains(l)) && l.isNotEmpty()) {
                best = ri.activityInfo.packageName
                bestLabel = label
            }
        }
        if (best == null) return jerr("'$wanted' 앱을 못 찾았어요")
        val launch = pm.getLaunchIntentForPackage(best) ?: return jerr("앱을 열 수 없어요")
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        a.startActivity(launch)
        return jok("app" to bestLabel)
    }

    private fun openUrl(a: Activity, url: String): String {
        val u = url.trim()
        if (!(u.startsWith("https://") || u.startsWith("http://"))) return jerr("http(s) 주소만 열 수 있어요")
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(u))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        a.startActivity(i)
        return jok("url" to u)
    }

    private fun setAlarm(a: Activity, time: String, label: String): String {
        val m = Regex("^(\\d{1,2}):(\\d{2})$").find(time.trim()) ?: return jerr("time 형식은 HH:MM")
        val h = m.groupValues[1].toInt()
        val mi = m.groupValues[2].toInt()
        if (h !in 0..23 || mi !in 0..59) return jerr("시간 범위가 올바르지 않아요")
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, mi)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (label.isNotBlank()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        a.startActivity(i)
        return jok("time" to String.format("%02d:%02d", h, mi))
    }

    private fun addNote(a: Activity, text: String): String {
        if (text.isBlank()) return jerr("메모 내용이 비었어요")
        val p = a.getSharedPreferences("localai", Context.MODE_PRIVATE)
        val old = p.getString("notes", "") ?: ""
        p.edit().putString("notes", if (old.isEmpty()) text else old + "\n" + text).apply()
        return jok()
    }

    private fun flashlight(a: Activity, on: Boolean): String {
        val cm = a.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        for (id in cm.cameraIdList) {
            val has = cm.getCameraCharacteristics(id)
                .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE)
            if (has == true) {
                cm.setTorchMode(id, on)
                return jok("on" to on)
            }
        }
        return jerr("손전등을 쓸 수 없는 기기예요")
    }

    private fun volume(a: Activity, level: Int): String {
        val am = a.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val lv = level.coerceIn(0, 100)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(max * lv / 100f), 0)
        return jok("volume" to lv)
    }
}
