package com.localai.phone

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class PhoneService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: PhoneService? = null

        fun tryAutoEnable(ctx: android.content.Context): Boolean {
            return try {
                val me = ctx.packageName + "/" + PhoneService::class.java.name
                val cur = android.provider.Settings.Secure.getString(
                    ctx.contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                ) ?: ""
                if (!cur.contains(me)) {
                    val next = if (cur.isEmpty()) me else "$cur:$me"
                    android.provider.Settings.Secure.putString(
                        ctx.contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, next
                    )
                }
                android.provider.Settings.Secure.putString(
                    ctx.contentResolver, android.provider.Settings.Secure.ACCESSIBILITY_ENABLED, "1"
                )
                true
            } catch (e: SecurityException) {
                false
            }
        }

        private val RISKY = listOf(
            "결제", "송금", "이체", "구매", "삭제", "탈퇴", "보내기", "전송",
            "pay", "send", "delete", "buy", "purchase", "transfer", "remove"
        )
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return Tools.jerr("화면을 읽을 수 없어요")
        val sb = StringBuilder()
        var count = 0
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || count >= 80 || sb.length >= 1500) return
            if (n.isVisibleToUser && !n.isPassword) {
                val t = (n.text ?: n.contentDescription)?.toString()?.trim()
                if (!t.isNullOrEmpty()) {
                    sb.append(t.take(120)).append('\n')
                    count++
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return Tools.jok("text" to sb.toString().take(1500))
    }

    private fun findByText(text: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val found = root.findAccessibilityNodeInfosByText(text)
        return found.firstOrNull { it.isVisibleToUser }
    }

    private fun clickable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var cur = n
        var depth = 0
        while (cur != null && depth < 6) {
            if (cur.isClickable) return cur
            cur = cur.parent
            depth++
        }
        return null
    }

    fun tapText(text: String): String {
        val t = text.trim()
        if (t.isEmpty()) return Tools.jerr("누를 글자가 비었어요")
        val low = t.lowercase()
        if (RISKY.any { low.contains(it) }) return Tools.jerr("위험한 동작이라 막았어요 (결제/삭제/전송 등)")
        val node = findByText(t) ?: return Tools.jerr("'$t' 글자를 화면에서 못 찾았어요")
        val target = clickable(node) ?: return Tools.jerr("눌 수 있는 버튼이 아니에요")
        val ok = target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        return if (ok) Tools.jok() else Tools.jerr("누르지 못했어요")
    }

    fun typeText(text: String): String {
        val root = rootInActiveWindow ?: return Tools.jerr("화면을 읽을 수 없어요")
        val focus = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: return Tools.jerr("선택된 입력칸이 없어요")
        if (focus.isPassword) return Tools.jerr("비밀번호 칸에는 입력하지 않아요")
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        val ok = focus.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        return if (ok) Tools.jok() else Tools.jerr("입력하지 못했어요")
    }

    fun pressKey(key: String): String {
        return when (key.trim().lowercase()) {
            "back" -> done(performGlobalAction(GLOBAL_ACTION_BACK))
            "home" -> done(performGlobalAction(GLOBAL_ACTION_HOME))
            "recents" -> done(performGlobalAction(GLOBAL_ACTION_RECENTS))
            "enter" -> {
                if (Build.VERSION.SDK_INT >= 30) {
                    val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                    val ok = f?.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id) ?: false
                    done(ok)
                } else Tools.jerr("이 안드로이드 버전에서는 엔터를 지원하지 않아요")
            }
            else -> Tools.jerr("key는 back, home, recents, enter 중 하나")
        }
    }

    private fun done(ok: Boolean): String = if (ok) Tools.jok() else Tools.jerr("동작에 실패했어요")

    fun scroll(direction: String): String {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val h = dm.heightPixels.toFloat()
        val down = direction.trim().lowercase() != "up"
        val p = Path()
        if (down) {
            p.moveTo(x, h * 0.7f); p.lineTo(x, h * 0.3f)
        } else {
            p.moveTo(x, h * 0.3f); p.lineTo(x, h * 0.7f)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 300))
            .build()
        val ok = dispatchGesture(g, null, null)
        return done(ok)
    }
}
