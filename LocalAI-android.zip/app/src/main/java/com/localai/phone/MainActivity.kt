package com.localai.phone

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.IOException

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    companion object {
        private const val HOST = "appassets.androidplatform.net"
        private const val PICK_CODE = 4242
        // 멀티스레드(WASM 스레드)를 시도하기 위한 헤더. 문제가 생기면 false로 바꾸세요.
        private const val ISOLATION_HEADERS = true
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.mediaPlaybackRequiresUserGesture = false

        web.addJavascriptInterface(Bridge(this, web), "Android")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url
                if (u.host != HOST) return null
                var path = u.path ?: "/"
                if (path == "/" || path.isEmpty()) path = "/index.html"
                path = path.removePrefix("/")
                return try {
                    val stream = assets.open(path)
                    val mime = when {
                        path.endsWith(".html") -> "text/html"
                        path.endsWith(".js") -> "text/javascript"
                        path.endsWith(".wasm") -> "application/wasm"
                        path.endsWith(".json") -> "application/json"
                        path.endsWith(".css") -> "text/css"
                        else -> "application/octet-stream"
                    }
                    val resp = WebResourceResponse(mime, "utf-8", stream)
                    val headers = HashMap<String, String>()
                    headers["Access-Control-Allow-Origin"] = "*"
                    if (ISOLATION_HEADERS) {
                        headers["Cross-Origin-Opener-Policy"] = "same-origin"
                        headers["Cross-Origin-Embedder-Policy"] = "require-corp"
                        headers["Cross-Origin-Resource-Policy"] = "same-origin"
                    }
                    resp.responseHeaders = headers
                    resp
                } catch (e: IOException) {
                    WebResourceResponse("text/plain", "utf-8", 404, "Not Found", HashMap(), null)
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == HOST) return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                } catch (e: Exception) {
                }
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                val i = Intent(Intent.ACTION_GET_CONTENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "*/*"
                return try {
                    startActivityForResult(Intent.createChooser(i, "파일 선택"), PICK_CODE)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        web.loadUrl("https://$HOST/index.html")
    }

    override fun onResume() {
        super.onResume()
        val prefs = getSharedPreferences("localai", MODE_PRIVATE)
        if (PhoneService.instance == null && !prefs.getBoolean("asked_a11y", false)) {
            prefs.edit().putBoolean("asked_a11y", true).apply()
            android.app.AlertDialog.Builder(this)
                .setTitle("폰 조작 허용")
                .setMessage("AI가 화면을 읽고 버튼을 눌러 폰을 대신 조작하도록 허용할까요? (결제·삭제·전송과 비밀번호 칸은 막혀 있어요)")
                .setPositiveButton("허용") { _, _ ->
                    if (!PhoneService.tryAutoEnable(this)) {
                        startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                }
                .setNegativeButton("허용 안 함", null)
                .show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_CODE) {
            val result: Array<Uri>? =
                if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            fileCallback?.onReceiveValue(result)
            fileCallback = null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
