package com.localai.phone

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class Bridge(private val activity: Activity, private val web: WebView) {
    private val prefs = activity.getSharedPreferences("localai", Context.MODE_PRIVATE)

    // ---- 음성: 읽어주기(TTS) ----
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val pending = ArrayList<Pair<Int, String>>()
    private var voiceName = ""
    private var rate = 1f
    private var pitch = 0.85f
    private var recognizer: SpeechRecognizer? = null
    private var lastRms = 0L

    init {
        activity.runOnUiThread {
            tts = TextToSpeech(activity) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val t = tts ?: return@TextToSpeech
                    t.language = Locale.KOREAN
                    t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) { ttsDone(utteranceId) }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) { ttsDone(utteranceId) }
                        override fun onError(utteranceId: String?, errorCode: Int) { ttsDone(utteranceId) }
                    })
                    ttsReady = true
                    applyVoice()
                    pending.forEach { doSpeak(it.first, it.second) }
                    pending.clear()
                }
            }
        }
    }

    private fun js(code: String) {
        activity.runOnUiThread { web.evaluateJavascript(code, null) }
    }

    private fun ttsDone(u: String?) {
        val id = u?.toIntOrNull() ?: return
        js("window.__ttsDone($id)")
    }

    private fun applyVoice() {
        val t = tts ?: return
        t.setSpeechRate(rate)
        t.setPitch(pitch)
        val ko = t.voices?.filter { it.locale.language == "ko" } ?: emptyList()
        val pick = ko.firstOrNull { it.name == voiceName }
            ?: ko.firstOrNull {
                val n = it.name.lowercase()
                (n.contains("koc") || n.contains("kod") || n.contains("male")) && !n.contains("female")
            }
            ?: ko.firstOrNull()
        if (pick != null) t.voice = pick
    }

    private fun doSpeak(id: Int, text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, id.toString())
    }

    @JavascriptInterface
    fun voiceList(): String {
        val arr = JSONArray()
        tts?.voices?.filter { it.locale.language == "ko" }?.forEach { arr.put(it.name) }
        return arr.toString()
    }

    @JavascriptInterface
    fun setVoice(name: String, r: Float, p: Float) {
        voiceName = name
        rate = r
        pitch = p
        activity.runOnUiThread { if (ttsReady) applyVoice() }
    }

    @JavascriptInterface
    fun speak(id: Int, text: String) {
        activity.runOnUiThread {
            if (ttsReady) doSpeak(id, text) else pending.add(Pair(id, text))
        }
    }

    @JavascriptInterface
    fun stopSpeak() {
        activity.runOnUiThread { tts?.stop() }
    }

    // ---- 음성: 듣기(STT, 폰 내장 우선) ----
    @JavascriptInterface
    fun hasMic(): Boolean =
        activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    @JavascriptInterface
    fun requestMic() {
        activity.runOnUiThread { activity.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7) }
    }

    @JavascriptInterface
    fun listen() {
        activity.runOnUiThread {
            if (!hasMic()) {
                requestMic()
                js("window.__sttResult('', '9')")
                return@runOnUiThread
            }
            if (!SpeechRecognizer.isRecognitionAvailable(activity)) {
                js("window.__sttResult('', 'unavailable')")
                return@runOnUiThread
            }
            recognizer?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(activity)
            recognizer = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {
                    val now = System.currentTimeMillis()
                    if (now - lastRms > 60) {
                        lastRms = now
                        js("window.__rms($rmsdB)")
                    }
                }
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { js("window.__sttResult('', '$error')") }
                override fun onResults(results: Bundle?) {
                    val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    js("window.__sttResult(${JSONObject.quote(t)}, '')")
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    js("window.__sttPartial(${JSONObject.quote(t)})")
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR")
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, activity.packageName)
            r.startListening(i)
        }
    }

    @JavascriptInterface
    fun stopListen() {
        activity.runOnUiThread { recognizer?.cancel() }
    }

    fun shutdown() {
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    @JavascriptInterface
    fun call(name: String, argsJson: String): String {
        val args = try { JSONObject(argsJson) } catch (e: Exception) { JSONObject() }
        return try {
            Tools.run(activity, name, args)
        } catch (e: Exception) {
            Tools.jerr("실행 중 오류: " + (e.message ?: "알 수 없음"))
        }
    }

    @JavascriptInterface
    fun hasApiKey(): Boolean = !prefs.getString("api_key", "").isNullOrBlank()

    @JavascriptInterface
    fun setApiKey(key: String) {
        prefs.edit().putString("api_key", key.trim()).apply()
    }

    @JavascriptInterface
    fun accessibilityOn(): Boolean = PhoneService.instance != null

    @JavascriptInterface
    fun openAccessibilitySettings() {
        // 편법: adb로 WRITE_SECURE_SETTINGS를 한 번 허용해 두면 앱이 스스로 켭니다.
        if (PhoneService.tryAutoEnable(activity)) return
        activity.runOnUiThread {
            val i = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(i)
        }
    }

    @JavascriptInterface
    fun openAppInfo() {
        activity.runOnUiThread {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = Uri.parse("package:" + activity.packageName)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(i)
        }
    }

    @JavascriptInterface
    fun askClaude(id: Int, prompt: String) {
        val key = prefs.getString("api_key", "") ?: ""
        Thread {
            var text = ""
            var err = ""
            try {
                text = ClaudeApi.ask(key, prompt)
            } catch (e: Exception) {
                err = e.message ?: "알 수 없는 오류"
            }
            val js = "window.__claudeDone($id, ${JSONObject.quote(text)}, ${if (err.isEmpty()) "null" else JSONObject.quote(err)})"
            activity.runOnUiThread { web.evaluateJavascript(js, null) }
        }.start()
    }
}
