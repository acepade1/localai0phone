package com.localai.phone

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject

class Bridge(private val activity: Activity, private val web: WebView) {
    private val prefs = activity.getSharedPreferences("localai", Context.MODE_PRIVATE)

    @JavascriptInterface
    fun call(name: String, argsJson: String): String {
        val args = try { JSONObject(argsJson) } catch (e: Exception) { JSONObject() }
        return try {
            Tools.run(activity, name, args)
        } catch (e: Exception) {
            Tools.jerr("실행 중 오류: " + (e.message ?: "알 수 없음"))
        }
    }

    @JavascriptInterface
    fun hasApiKey(): Boolean = !prefs.getString("api_key", "").isNullOrBlank()

    @JavascriptInterface
    fun setApiKey(key: String) {
        prefs.edit().putString("api_key", key.trim()).apply()
    }

    @JavascriptInterface
    fun accessibilityOn(): Boolean = PhoneService.instance != null

    @JavascriptInterface
    fun openAccessibilitySettings() {
        // 편법: adb로 WRITE_SECURE_SETTINGS를 한 번 허용해 두면 앱이 스스로 켭니다.
        if (PhoneService.tryAutoEnable(activity)) return
        activity.runOnUiThread {
            val i = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(i)
        }
    }

    @JavascriptInterface
    fun openAppInfo() {
        activity.runOnUiThread {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = Uri.parse("package:" + activity.packageName)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(i)
        }
    }

    @JavascriptInterface
    fun askClaude(id: Int, prompt: String) {
        val key = prefs.getString("api_key", "") ?: ""
        Thread {
            var text = ""
            var err = ""
            try {
                text = ClaudeApi.ask(key, prompt)
            } catch (e: Exception) {
                err = e.message ?: "알 수 없는 오류"
            }
            val js = "window.__claudeDone($id, ${JSONObject.quote(text)}, ${if (err.isEmpty()) "null" else JSONObject.quote(err)})"
            activity.runOnUiThread { web.evaluateJavascript(js, null) }
        }.start()
    }
}
