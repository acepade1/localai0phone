package com.localai.phone

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ClaudeApi {
    private const val MODEL = "claude-sonnet-5-5"

    fun ask(apiKey: String, prompt: String): String {
        if (apiKey.isBlank()) throw Exception("API 키가 없어요")
        val body = JSONObject()
        body.put("model", MODEL)
        body.put("max_tokens", 1500)
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "user").put("content", prompt))
        body.put("messages", msgs)

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 90000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", apiKey)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw Exception("Claude 응답 오류 ($code)")

            val content = JSONObject(text).optJSONArray("content") ?: return ""
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                if (b.optString("type") == "text") sb.append(b.optString("text"))
            }
            return sb.toString()
        } finally {
            conn.disconnect()
        }
    }
}
