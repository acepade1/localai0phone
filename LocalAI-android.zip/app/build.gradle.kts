plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.localai.phone"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.localai.phone"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // 큰 파일(wasm 등)은 압축하지 않아야 앱이 빨리 열려요.
    androidResources {
        noCompress += listOf("wasm", "js", "html")
    }
}

// 외부 라이브러리 없이 안드로이드 기본 기능만 써요.
dependencies {
}
